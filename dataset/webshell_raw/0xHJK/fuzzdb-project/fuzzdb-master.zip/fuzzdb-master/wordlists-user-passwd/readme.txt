
various notes

leetspeak filter 
cat plain.wordlist | sed -e 's/a/4/g' -e 's/e/3/g' -e 's/i/1/g' -e 's/o/0/g' -e 's/s/5/g' -e 's/t/7/g' > l337.wordlist


Defaults for a number of appservers
https://github.com/pwnwiki/webappdefaultsdb

more wordlists
ftp://ftp.ox.ac.uk/pub/wordlists/
http://theargon.com/achilles/wordlists/
http://www.totse.com/en/hack/word_lists/index.html
http://www.outpost9.com/files/WordLists.html
http://packetstormsecurity.org/Crackers/wordlists/

passwd brute force tools

cupp - passwd profiler
http://www.remote-exploit.org/?page_id=506

awlg - associative wordlist generator
http://awlg.org/index.gen

thc-hydra
http://freeworld.thc.org/thc-hydra/

cain & abel
http://www.oxid.it/cain.html

jtr
http://www.openwall.com/john/

lcp - free l0phtcrack replacement
http://www.lcpsoft.com/english/download.htm

1.4 billion password wordlist (4gb+, too big to include in FuzzDB)
https://gist.github.com/scottlinux/9a3b11257ac575e4f71de811322ce6b3

