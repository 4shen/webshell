NoSQL Hacking Docs
==================
- https://www.owasp.org/index.php/Testing_for_NoSQL_injection
- https://arxiv.org/pdf/1506.04082.pdf
- https://pentesterlab.com/exercises/web_for_pentester_II/course
- https://ckarande.gitbooks.io/owasp-nodegoat-tutorial/content/tutorial/a1_-_sql_and_nosql_injection.html
- https://www.defcon.org/images/defcon-21/dc-21-presentations/Chow/DEFCON-21-Chow-Abusing-NoSQL-Databases.pdf
- http://blog.websecurify.com/2014/08/hacking-nodejs-and-mongodb.html

NoSQL Hacking Tools
===================
- http://nosqlmap.net/index.html 

Credits
=======
Thanks to https://github.com/cr0hn/nosqlinjection_wordlists for starting this wordlist
