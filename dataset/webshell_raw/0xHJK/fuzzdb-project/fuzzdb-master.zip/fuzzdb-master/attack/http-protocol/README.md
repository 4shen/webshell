References:

https://web.archive.org/web/20150426090054/http://ha.ckers.org/response-splitting.html
