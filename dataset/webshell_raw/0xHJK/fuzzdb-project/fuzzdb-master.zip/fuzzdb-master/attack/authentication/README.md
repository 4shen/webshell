
php_magic_hashes.fuzz.txt - See, https://www.whitehatsec.com/blog/magic-hashes/
"the following “magic” strings are substantially more likely to evaluate to true when hashed given a completely random hash..."

